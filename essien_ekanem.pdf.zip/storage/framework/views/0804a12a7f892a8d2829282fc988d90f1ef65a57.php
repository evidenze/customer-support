<?php $__env->startSection('content'); ?>
<div class="container">
    <h5 class="dashboard">TICKET DETAILS</h5>
</div>

<div class="container">
    <?php if( session()->has('edit')): ?>
                      <div class="alert alert-success" role="alert"><?php echo e(session()->get('edit')); ?></div>
                  <?php endif; ?>
    <div class="card">
    <div class="card-body">
<?php if($ticket->active == null): ?>
    <div class="alert alert-danger" role="alert">
  This ticket as been marked as closed
</div>
<?php endif; ?>
    <div class="row">
        <div class="col-md-3">
            <h5 class="show">Ticket ID</h5><br>
            <h6><?php echo e($ticket->ticket_id); ?></h6>
            
        </div>
    <div class="col-md-3">
        <h5 class="show">Status</h5><br>
        <h6><?php if($ticket->active == 1): ?>
                <span class="badge badge-success">Active</span>
            <?php else: ?>
                <span class="badge badge-secondary">Closed</span>
            <?php endif; ?>
            </h6>
        
    </div>
    <div class="col-md-3">
        <h5 class="show">Date Created</h5><br>
        <h6><?php echo e($ticket->created_at); ?></h6>
        
    </div>
    <div class="col-md-3">
        <h5 class="show">Date Updated</h5><br>
        <h6><?php echo e($ticket->updated_at); ?></h6>
        
    </div>
</div>
</div><br><br><br>
<div class="container">
    <h5 class="show">Description</h5><br>
    <p><?php echo e($ticket->description); ?></p><br><br><br>

    <?php if($ticket->active == null): ?>
       <button type="button" class="btn btn-success" disabled>Edit</button>&nbsp&nbsp
       <button type="button" class="btn btn-warning" disabled>Close</button>
    <?php else: ?>
    <a class="btn btn-success edit" href="<?php echo e(route('ticket.edit', $ticket->id)); ?>" role="button">Edit</a>&nbsp&nbsp
    <a class="btn btn-warning" href="<?php echo e(route('close', $ticket->id)); ?>" role="button">Close</a>
    <?php endif; ?> 
    &nbsp&nbsp<a class="btn btn-danger" href="<?php echo e(route('ticket.destroy', $ticket->id)); ?>" onclick="event.preventDefault();
                                                     document.getElementById('delete-form').submit();" role="button">Delete</a>
                                                      <form id="delete-form" action="<?php echo e(route('ticket.destroy', $ticket->id)); ?>" method="POST" style="display: none;">
                                                        <?php echo e(method_field('DELETE')); ?>

                                                        <?php echo e(csrf_field()); ?>

                                                     </form><br><br><br>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>