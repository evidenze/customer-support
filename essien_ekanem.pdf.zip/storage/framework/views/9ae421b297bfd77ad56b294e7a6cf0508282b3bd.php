<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="dashboard">DASHBOARD</h4>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card text-center">
              <div class="card-body" style="background-color:#1e88e5;color:#fff;">
                <h1 class="stat"><a class="data" href="<?php echo e(route('tickets')); ?>"><?php echo e($allTickets); ?></a></h1>
                <h3><a class="data" href="<?php echo e(route('tickets')); ?>">Total Tickets</a></h3>
              </div>
            </div>
            
        </div>
        <div class="col-md-4">
            <div class="card text-center">
              <div class="card-body" style="background-color:#ef5350  ;color:#fff;">
                <h1 class="stat"><?php echo e($open); ?></h1>
                <h3>Active Tickets</h3>
              </div>
            </div>
            
        </div>
        <div class="col-md-4">
            <div class="card text-center">
              <div class="card-body" style="background-color:#00e676 ;color:#fff;">
               <h1 class="stat"><?php echo e($closed); ?></h1>
                <h3>Closed Tickets</h3>
              </div>
            </div>
            
        </div>
    </div><br><br>
    <hr>

    <div class="card">
      <div class="card-body">
    <h4 style="margin-top:20px;color:#263238;font-weight:bold;">TICKETS</h4>

  <?php if($allTickets >= 1): ?>
    <p>Click on ticket ID to show details<p>
    <a class="btn btn-primary float-right" href="<?php echo e(route('ticket.create')); ?>" role="button">Add New Ticket</a><br><br>
  <?php endif; ?>

  <?php if($allTickets == 0): ?>

        <h2 class="text-center">No ticket found</h2><br><br>
        <p class="text-center"><a class="btn btn-primary float-center" href="<?php echo e(route('ticket.create')); ?>" role="button">Add New Ticket</a></p>
  <?php else: ?>
        <table class="table table-striped">

      <thead>
        <tr>
          <th scope="col">Ticket ID</th>
          <th scope="col">Subject</th>
          <th scope="col">Status</th>
          <th scope="col">Priority</th>
          <th scope="col"></th>
        </tr>
      </thead>
      <tbody>
  <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><a class="id" href="<?php echo e(route('ticket.show', $data->id)); ?>"><?php echo e($data->ticket_id); ?></td>
          <td><?php echo e($data->subject); ?></td>
          <td>
            <?php if($data->active == 1): ?>
                              <span class="badge badge-success">Active</span>
            <?php else: ?>
              <span class="badge badge-secondary">Closed</span>
            <?php endif; ?>
          </td>
          <td><?php echo e($data->priority); ?></td>
          <td>
        <?php if($data->active == null): ?>

             <button type="button" class="btn btn-success" disabled>Edit</button>&nbsp&nbsp
             <button type="button" class="btn btn-warning" disabled>Close</button>
        <?php else: ?>
          <a class="btn btn-success edit" href="<?php echo e(route('ticket.edit', $data->id)); ?>" role="button">Edit</a>&nbsp&nbsp
          <a class="btn btn-warning" href="<?php echo e(route('close', $data->id)); ?>">Close</a>
        <?php endif; ?>
          &nbsp&nbsp          
          <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal">Delete</button>                                                  
        </td>
        </tr>

        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure you want to remove this ticket?<br>
        <?php echo e($data->ticket_id); ?>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" id="check" value="<?php echo e($data->id); ?>">Delete</button>
      </div>
    </div>
  </div>
</div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table><br><br><br>
      </div>
        <?php echo e($datas->links()); ?>

  <?php endif; ?>
    </div></div><br><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>